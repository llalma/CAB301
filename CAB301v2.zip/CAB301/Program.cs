﻿using System;
using Enums;

namespace CAB301
{
    class Program
    {
        static void Main(string[] args)
        {
            new GUI();


            
        }
    }
}
